package com.example.signaltracker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.Locale;

/** نوتیفیکیشن‌ها و آلارم صوتی/لرزشی. */
final class Notifier {
    private Notifier() {}

    static final String CH_SERVICE = "sp_service";
    static final String CH_ALARM = "sp_alarm";
    static final String CH_RESULT = "sp_result";

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static MediaPlayer player;
    private static Vibrator vib;
    private static Runnable stopTask;

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        NotificationChannel s = new NotificationChannel(CH_SERVICE, "اتصال به تلگرام", NotificationManager.IMPORTANCE_LOW);
        s.setShowBadge(false);
        nm.createNotificationChannel(s);

        NotificationChannel a = new NotificationChannel(CH_ALARM, "آلارم سیگنال", NotificationManager.IMPORTANCE_HIGH);
        a.setSound(null, null); // صدا را خودمان با کانال «آلارم» پخش می‌کنیم
        a.enableVibration(true);
        a.setVibrationPattern(new long[]{0, 500, 250, 500});
        a.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(a);

        NotificationChannel r = new NotificationChannel(CH_RESULT, "نتیجه سیگنال", NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(r);
    }

    static Notification serviceNotification(Context c, String text) {
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(c, CH_SERVICE)
                .setSmallIcon(R.drawable.ic_stat_signal)
                .setContentTitle("سیگنال‌یار فعال است")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    /** آلارم سیگنال جدید. اگر alarmSeconds <= 0 باشد فقط نوتیفیکیشن (بدون صدا) نمایش داده می‌شود. */
    static void signalAlarm(Context c, SignalStore.Signal s, int alarmSeconds) {
        ensureChannels(c);
        int nid = Math.abs(s.id.hashCode());
        String side = s.buy ? "خرید" : "فروش";
        String title = (s.buy ? "\uD83D\uDFE2 " : "\uD83D\uDD34 ") + "سیگنال " + side + " " + s.symbol
                + (s.tf.isEmpty() ? "" : " · " + s.tf);
        String text = "ورود " + SignalStore.fmt(s.entry) + "  |  حد ضرر " + SignalStore.fmt(s.sl)
                + "  |  TP2 " + SignalStore.fmt(s.tp2);
        String big = text + "\nTP1 " + SignalStore.fmt(s.tp1) + "  |  TP3 " + SignalStore.fmt(s.tp3)
                + "\nریسک شبیه‌سازی: " + String.format(Locale.US, "%.2f", s.risk) + "٪ · R:R 1:"
                + String.format(Locale.US, "%.1f", s.rr());

        Intent full = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent fullPi = PendingIntent.getActivity(c, nid * 3, full, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent tap = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("stop_alarm", true);
        PendingIntent tapPi = PendingIntent.getActivity(c, nid * 3 + 1, tap, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(c, StopAlarmReceiver.class);
        PendingIntent stopPi = PendingIntent.getBroadcast(c, nid * 3 + 2, stop, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_ALARM)
                .setSmallIcon(R.drawable.ic_stat_signal)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(big))
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setColor(s.buy ? 0xFF26A69A : 0xFFEF5350)
                .setAutoCancel(true)
                .setContentIntent(tapPi)
                .setFullScreenIntent(fullPi, true)
                .setVibrate(new long[]{0, 500, 250, 500});
        if (alarmSeconds > 0) b.addAction(0, "توقف آلارم", stopPi);

        try {
            NotificationManagerCompat.from(c).notify(nid, b.build());
        } catch (Exception ignored) {
        }
        if (alarmSeconds > 0) startAlarm(c, alarmSeconds);
    }

    static void resultNotification(Context c, SignalStore.Signal s) {
        ensureChannels(c);
        String title;
        if ("TP2".equals(s.status)) title = "\u2705 TP2 زده شد · " + s.symbol;
        else if ("SL".equals(s.status)) title = "\u274C حد ضرر فعال شد · " + s.symbol;
        else title = "\u23F1 سیگنال منقضی شد · " + s.symbol;
        String text = "نتیجه شبیه‌سازی: " + (s.pnl >= 0 ? "+" : "") + String.format(Locale.US, "%.2f", s.pnl) + "٪";

        Intent open = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, Math.abs(s.id.hashCode()) * 3 + 100, open, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_RESULT)
                .setSmallIcon(R.drawable.ic_stat_signal)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setColor("TP2".equals(s.status) ? 0xFF26A69A : 0xFFEF5350)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        try {
            NotificationManagerCompat.from(c).notify(Math.abs(s.id.hashCode()) + 7, b.build());
        } catch (Exception ignored) {
        }
    }

    // ---------------- آلارم صوتی و لرزش ----------------

    static void startAlarm(final Context c, final int seconds) {
        final Context app = c.getApplicationContext();
        H.post(new Runnable() {
            @Override public void run() { startAlarmInternal(app, seconds); }
        });
    }

    private static synchronized void startAlarmInternal(Context c, int seconds) {
        stopAlarmInternal();
        try {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(c, u);
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mp.setLooping(true);
            mp.prepare();
            mp.start();
            player = mp;
        } catch (Exception e) {
            player = null;
        }
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                long[] pat = {0, 700, 400, 700, 400};
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pat, 0));
                else v.vibrate(pat, 0);
                vib = v;
            }
        } catch (Exception ignored) {
        }
        stopTask = new Runnable() {
            @Override public void run() { stopAlarm(); }
        };
        H.postDelayed(stopTask, Math.max(3, seconds) * 1000L);
        SignalStore.notifyChanged();
    }

    static void stopAlarm() {
        H.post(new Runnable() {
            @Override public void run() {
                stopAlarmInternal();
                SignalStore.notifyChanged();
            }
        });
    }

    private static synchronized void stopAlarmInternal() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        if (vib != null) {
            try { vib.cancel(); } catch (Exception ignored) { }
            vib = null;
        }
        if (stopTask != null) {
            H.removeCallbacks(stopTask);
            stopTask = null;
        }
    }

    static synchronized boolean isAlarmPlaying() {
        return player != null;
    }
}
