package com.example.signaltracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SignalAdapter extends RecyclerView.Adapter<SignalAdapter.VH> {
    private final List<SignalStore.Signal> items = new ArrayList<>();
    private final SimpleDateFormat df = new SimpleDateFormat("dd/MM  HH:mm", Locale.US);

    public void submit(List<SignalStore.Signal> list) {
        items.clear();
        items.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_signal, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(VH h, int position) {
        SignalStore.Signal s = items.get(position);
        int green = 0xFF26A69A, red = 0xFFEF5350, amber = 0xFFFFB74D, gray = 0xFF787B86;

        h.tvSide.setText(s.buy ? "خرید BUY" : "فروش SELL");
        h.tvSide.setTextColor(s.buy ? green : red);
        h.tvSide.setBackgroundResource(s.buy ? R.drawable.bg_badge_green : R.drawable.bg_badge_red);
        h.strip.setBackgroundColor(s.buy ? green : red);

        h.tvSymbol.setText(s.symbol + (s.tf.isEmpty() ? "" : "  ·  " + s.tf));
        String meta = (s.strategy.isEmpty() ? "" : s.strategy + "  ·  ") + df.format(new Date(s.time));
        h.tvMeta.setText(meta);

        h.tvEntry.setText(SignalStore.fmt(s.entry));
        h.tvSl.setText(SignalStore.fmt(s.sl));
        h.tvTp2.setText(SignalStore.fmt(s.tp2));
        h.tvExtra.setText("TP1 " + SignalStore.fmt(s.tp1) + "   ·   TP3 " + SignalStore.fmt(s.tp3)
                + "   ·   R:R 1:" + String.format(Locale.US, "%.1f", s.rr()));

        String pnl = (s.pnl >= 0 ? "+" : "") + String.format(Locale.US, "%.2f", s.pnl) + "%";
        if ("TP2".equals(s.status)) {
            h.tvStatus.setText("TP2 ✓  " + pnl);
            h.tvStatus.setTextColor(green);
            h.tvStatus.setBackgroundResource(R.drawable.bg_badge_green);
        } else if ("SL".equals(s.status)) {
            h.tvStatus.setText("SL ✗  " + pnl);
            h.tvStatus.setTextColor(red);
            h.tvStatus.setBackgroundResource(R.drawable.bg_badge_red);
        } else if ("EXPIRED".equals(s.status)) {
            h.tvStatus.setText("منقضی");
            h.tvStatus.setTextColor(gray);
            h.tvStatus.setBackgroundResource(R.drawable.bg_badge_gray);
        } else {
            h.tvStatus.setText("در جریان");
            h.tvStatus.setTextColor(amber);
            h.tvStatus.setBackgroundResource(R.drawable.bg_badge_amber);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView tvSide, tvSymbol, tvStatus, tvMeta, tvEntry, tvSl, tvTp2, tvExtra;
        final View strip;

        VH(View v) {
            super(v);
            tvSide = v.findViewById(R.id.tvSide);
            tvSymbol = v.findViewById(R.id.tvSymbol);
            tvStatus = v.findViewById(R.id.tvStatus);
            tvMeta = v.findViewById(R.id.tvMeta);
            tvEntry = v.findViewById(R.id.tvEntry);
            tvSl = v.findViewById(R.id.tvSl);
            tvTp2 = v.findViewById(R.id.tvTp2);
            tvExtra = v.findViewById(R.id.tvExtra);
            strip = v.findViewById(R.id.vStrip);
        }
    }
}
