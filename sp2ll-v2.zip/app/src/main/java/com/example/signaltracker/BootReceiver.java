package com.example.signaltracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** بعد از روشن شدن گوشی یا آپدیت برنامه، اگر دریافت فعال بوده دوباره شروع می‌شود. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String a = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            if (Prefs.running(context)) {
                try {
                    SignalService.start(context);
                } catch (Exception ignored) {
                }
            }
        }
    }
}
