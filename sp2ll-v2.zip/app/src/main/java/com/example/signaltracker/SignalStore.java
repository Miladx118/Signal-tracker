package com.example.signaltracker;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** ذخیره‌سازی سیگنال‌ها + آمار و شبیه‌سازی ریسک ثابت درصدی. */
final class SignalStore {
    private SignalStore() {}

    static final class Signal {
        String id = "";
        long msgId;
        boolean buy;
        String symbol = "";
        String tf = "";
        String strategy = "";
        long time;              // زمان دریافت (میلی‌ثانیه)
        double entry, sl, tp1, tp2, tp3;
        double risk;            // درصد ریسک شبیه‌سازی در لحظه دریافت
        String status = "OPEN"; // OPEN | TP2 | SL | EXPIRED
        long closedAt;
        double pnl;             // سود/زیان شبیه‌سازی (درصد از موجودی)

        double rr() {
            double r = Math.abs(entry - sl);
            return r > 0 ? Math.abs(tp2 - entry) / r : 0;
        }

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("msgId", msgId); o.put("buy", buy);
            o.put("symbol", symbol); o.put("tf", tf); o.put("strategy", strategy);
            o.put("time", time); o.put("entry", entry); o.put("sl", sl);
            o.put("tp1", tp1); o.put("tp2", tp2); o.put("tp3", tp3);
            o.put("risk", risk); o.put("status", status);
            o.put("closedAt", closedAt); o.put("pnl", pnl);
            return o;
        }

        static Signal fromJson(JSONObject o) {
            Signal s = new Signal();
            s.id = o.optString("id"); s.msgId = o.optLong("msgId"); s.buy = o.optBoolean("buy");
            s.symbol = o.optString("symbol"); s.tf = o.optString("tf"); s.strategy = o.optString("strategy");
            s.time = o.optLong("time"); s.entry = o.optDouble("entry"); s.sl = o.optDouble("sl");
            s.tp1 = o.optDouble("tp1"); s.tp2 = o.optDouble("tp2"); s.tp3 = o.optDouble("tp3");
            s.risk = o.optDouble("risk", 0.5); s.status = o.optString("status", "OPEN");
            s.closedAt = o.optLong("closedAt"); s.pnl = o.optDouble("pnl", 0);
            return s;
        }
    }

    static final class Stats {
        int wins, losses, open, expired;
        double start, balance, netPct, winRate;
        final List<Double> equity = new ArrayList<>();
    }

    private static final String KEY = "signals";
    private static final int MAX = 300;
    private static final List<Signal> list = new ArrayList<>();
    private static boolean loaded = false;
    private static Runnable listener;
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static String status = "متوقف";
    private static boolean statusOk = false;

    static String fmt(double v) {
        try {
            return new BigDecimal(String.valueOf(v)).toPlainString();
        } catch (Exception e) {
            return String.valueOf(v);
        }
    }

    private static synchronized void load(Context c) {
        if (loaded) return;
        loaded = true;
        list.clear();
        try {
            String raw = c.getApplicationContext().getSharedPreferences("sp2ll_data", Context.MODE_PRIVATE)
                    .getString(KEY, "[]");
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) list.add(Signal.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {
        }
    }

    private static void save(Context c) {
        try {
            JSONArray a = new JSONArray();
            for (Signal s : list) a.put(s.toJson());
            c.getApplicationContext().getSharedPreferences("sp2ll_data", Context.MODE_PRIVATE)
                    .edit().putString(KEY, a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** false یعنی این سیگنال قبلاً ثبت شده بود. */
    static synchronized boolean add(Context c, Signal s) {
        load(c);
        for (Signal x : list) if (x.id.equals(s.id)) return false;
        list.add(0, s);
        while (list.size() > MAX) list.remove(list.size() - 1);
        save(c);
        notifyChanged();
        return true;
    }

    /** نتیجه (TP2/SL/EXPIRED) را روی سیگنال باز اعمال می‌کند؛ اگر سیگنال پیدا نشد null. */
    static synchronized Signal applyResult(Context c, String id, String kind, long when) {
        load(c);
        for (Signal s : list) {
            if (!s.id.equals(id)) continue;
            if (!"OPEN".equals(s.status)) return null;
            s.status = kind;
            s.closedAt = when;
            if ("TP2".equals(kind)) s.pnl = s.risk * s.rr();
            else if ("SL".equals(kind)) s.pnl = -s.risk;
            else s.pnl = 0;
            save(c);
            notifyChanged();
            return s;
        }
        return null;
    }

    static synchronized List<Signal> snapshot(Context c) {
        load(c);
        return new ArrayList<>(list);
    }

    static synchronized void clear(Context c) {
        load(c);
        list.clear();
        save(c);
        notifyChanged();
    }

    static synchronized Stats stats(Context c) {
        load(c);
        Stats st = new Stats();
        st.start = Prefs.startBalance(c);
        List<Signal> closed = new ArrayList<>();
        for (Signal s : list) {
            if ("TP2".equals(s.status)) { st.wins++; closed.add(s); }
            else if ("SL".equals(s.status)) { st.losses++; closed.add(s); }
            else if ("EXPIRED".equals(s.status)) st.expired++;
            else st.open++;
        }
        Collections.sort(closed, (a, b) -> Long.compare(a.closedAt, b.closedAt));
        double bal = st.start;
        st.equity.add(bal);
        for (Signal s : closed) {
            bal *= 1.0 + s.pnl / 100.0;
            st.equity.add(bal);
        }
        st.balance = bal;
        st.netPct = st.start > 0 ? (bal / st.start - 1.0) * 100.0 : 0;
        int n = st.wins + st.losses;
        st.winRate = n > 0 ? 100.0 * st.wins / n : 0;
        return st;
    }

    static void setStatus(String t, boolean ok) {
        status = t;
        statusOk = ok;
        notifyChanged();
    }

    static String status() { return status; }
    static boolean statusOk() { return statusOk; }

    static void setListener(Runnable r) { listener = r; }

    static void notifyChanged() {
        final Runnable r = listener;
        if (r != null) main.post(r);
    }
}
