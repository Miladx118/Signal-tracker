package com.example.signaltracker;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * تجزیه پیام‌های ربات تلگرام اکسپرت (FixedTimeBoxEA).
 * این کلاس عمداً هیچ وابستگی به اندروید ندارد تا قابل تست باشد.
 */
final class SignalParser {
    private SignalParser() {}

    static final class Parsed {
        String kind;        // "SIGNAL" یا "RESULT"
        String id;
        String resultKind;  // "TP2" | "SL" | "EXPIRED"
        boolean buy;
        String symbol = "";
        String tf = "";
        String strategy = "";
        double entry, sl, tp1, tp2, tp3;
    }

    private static final Pattern ID = Pattern.compile("#([A-Za-z0-9]+(?:_[A-Za-z0-9]+)+)");
    private static final Pattern SIDE = Pattern.compile("\\b(BUY|SELL)\\s+([A-Za-z0-9._#\\-]+)");
    private static final Pattern TF_FA = Pattern.compile("تایم.?فریم سیگنال:\\s*(\\S+)");
    private static final Pattern TF_PAREN = Pattern.compile("\\(([A-Z]+[0-9]+)\\)");
    private static final Pattern STRATEGY = Pattern.compile("استراتژی:\\s*([^\\r\\n]+)");

    /** پیام تست (🧪) و پیام‌های نامرتبط null برمی‌گردانند. */
    static Parsed parse(String text) {
        if (text == null || text.isEmpty()) return null;
        if (text.contains("\uD83E\uDDEA")) return null; // 🧪 پیام تست

        String resKind = null;
        if (text.contains("STOP LOSS HIT")) resKind = "SL";
        else if (text.contains("TP2 HIT")) resKind = "TP2";
        else if (text.contains("EXPIRED")) resKind = "EXPIRED";

        Matcher mi = ID.matcher(text);
        String id = mi.find() ? mi.group(1) : null;

        if (resKind != null) {
            if (id == null) return null;
            Parsed r = new Parsed();
            r.kind = "RESULT";
            r.id = id;
            r.resultKind = resKind;
            return r;
        }

        if (!text.contains("SIGNAL")) return null;

        Matcher ms = SIDE.matcher(text);
        if (!ms.find()) return null;

        Double entry = num(text, "Entry");
        Double sl = num(text, "SL");
        Double tp1 = num(text, "TP1");
        Double tp2 = num(text, "TP2");
        Double tp3 = num(text, "TP3");
        if (entry == null || sl == null || tp2 == null) return null;

        Parsed p = new Parsed();
        p.kind = "SIGNAL";
        p.buy = "BUY".equals(ms.group(1));
        p.symbol = ms.group(2);
        p.entry = entry;
        p.sl = sl;
        p.tp2 = tp2;
        p.tp1 = tp1 != null ? tp1 : entry + (tp2 - entry) / 2.0;
        p.tp3 = tp3 != null ? tp3 : entry + (tp2 - entry) * 1.5;

        // اعتبارسنجی جهت: خرید => SL < Entry < TP2 ، فروش => SL > Entry > TP2
        if (p.buy && !(p.sl < p.entry && p.entry < p.tp2)) return null;
        if (!p.buy && !(p.sl > p.entry && p.entry > p.tp2)) return null;

        Matcher mt = TF_FA.matcher(text);
        if (mt.find()) p.tf = mt.group(1);
        else {
            Matcher mp = TF_PAREN.matcher(text);
            if (mp.find()) p.tf = mp.group(1);
        }
        Matcher mst = STRATEGY.matcher(text);
        if (mst.find()) p.strategy = mst.group(1).trim();

        p.id = (id != null) ? id : (p.buy ? "B_" : "S_") + p.symbol + "_" + p.entry;
        return p;
    }

    private static Double num(String text, String label) {
        Matcher m = Pattern.compile("(?<![A-Za-z])" + label + "\\s*:\\s*(-?\\d+(?:[.,]\\d+)?)").matcher(text);
        if (!m.find()) return null;
        try {
            return Double.parseDouble(m.group(1).replace(',', '.'));
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
