package com.example.signaltracker;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Locale;

public class SettingsActivity extends AppCompatActivity {

    private TextInputEditText etToken, etChannel, etBalance, etRisk, etAlarmSec;
    private SwitchMaterial swAlarm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        etToken = findViewById(R.id.etToken);
        etChannel = findViewById(R.id.etChannel);
        etBalance = findViewById(R.id.etBalance);
        etRisk = findViewById(R.id.etRisk);
        etAlarmSec = findViewById(R.id.etAlarmSec);
        swAlarm = findViewById(R.id.swAlarm);

        etToken.setText(Prefs.token(this));
        etChannel.setText(Prefs.channel(this));
        etBalance.setText(trim(Prefs.startBalance(this)));
        etRisk.setText(trim(Prefs.riskPct(this)));
        etAlarmSec.setText(String.valueOf(Prefs.alarmSeconds(this)));
        swAlarm.setChecked(Prefs.alarmOn(this));

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        });
        findViewById(R.id.btnTestAlarm).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { testAlarm(); }
        });
        findViewById(R.id.btnBattery).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { batteryOptimization(); }
        });
        findViewById(R.id.btnClear).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmClear(); }
        });
    }

    private static String trim(double v) {
        if (v == Math.floor(v)) return String.valueOf((long) v);
        return String.valueOf(v);
    }

    private static double parseD(CharSequence cs, double def) {
        try {
            return Double.parseDouble(cs.toString().trim().replace(',', '.'));
        } catch (Exception e) {
            return def;
        }
    }

    private void save() {
        String token = String.valueOf(etToken.getText()).trim();
        String channel = String.valueOf(etChannel.getText()).trim();
        double bal = parseD(String.valueOf(etBalance.getText()), -1);
        double risk = parseD(String.valueOf(etRisk.getText()), -1);
        int sec;
        try {
            sec = Integer.parseInt(String.valueOf(etAlarmSec.getText()).trim());
        } catch (Exception e) {
            sec = -1;
        }
        if (token.isEmpty() || channel.isEmpty()) {
            toast("توکن ربات و آیدی کانال را وارد کنید");
            return;
        }
        if (bal <= 0) { toast("موجودی اولیه باید بزرگتر از صفر باشد"); return; }
        if (risk <= 0 || risk > 10) { toast("درصد ریسک باید بین 0.01 تا 10 باشد"); return; }
        if (sec < 3 || sec > 120) { toast("مدت آلارم باید بین 3 تا 120 ثانیه باشد"); return; }

        Prefs.save(this, token, channel, bal, risk, sec, swAlarm.isChecked());
        SignalStore.notifyChanged();
        toast("ذخیره شد");
        finish();
    }

    private void testAlarm() {
        if (Notifier.isAlarmPlaying()) {
            Notifier.stopAlarm();
            return;
        }
        int sec = 6;
        Notifier.startAlarm(this, sec);
        toast("آلارم آزمایشی (" + sec + " ثانیه). اگر صدا نیامد، صدای «آلارم» گوشی را زیاد کنید.");
    }

    private void batteryOptimization() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= 23 && pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                toast("برنامه از قبل از بهینه‌سازی باتری مستثناست");
                return;
            }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
                toast("تنظیمات باتری باز نشد؛ دستی انجام دهید");
            }
        }
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("پاک کردن تاریخچه")
                .setMessage("همه سیگنال‌ها و آمار شبیه‌سازی پاک می‌شود. ادامه می‌دهید؟")
                .setPositiveButton("پاک کن", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        SignalStore.clear(SettingsActivity.this);
                        toast("تاریخچه پاک شد");
                    }
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }
}
