package com.example.signaltracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** نمودار کوچک رشد موجودی (Sparkline). */
public class EquityView extends View {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint base = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Double> data = new ArrayList<>();

    public EquityView(Context c, AttributeSet a) {
        super(c, a);
        float d = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2f * d);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        base.setColor(0x33FFFFFF);
        base.setStrokeWidth(1f * d);
    }

    public void setData(List<Double> d) {
        data = new ArrayList<>(d);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        float pad = 4f * getResources().getDisplayMetrics().density;
        int n = data.size();
        if (n < 2) {
            canvas.drawLine(pad, h / 2f, w - pad, h / 2f, base);
            return;
        }
        double min = Double.MAX_VALUE, max = -Double.MAX_VALUE;
        for (double v : data) {
            if (v < min) min = v;
            if (v > max) max = v;
        }
        if (max - min < 1e-9) max = min + 1;
        Path p = new Path();
        for (int i = 0; i < n; i++) {
            float x = pad + (w - 2 * pad) * i / (n - 1f);
            float y = h - pad - (h - 2 * pad) * (float) ((data.get(i) - min) / (max - min));
            if (i == 0) p.moveTo(x, y);
            else p.lineTo(x, y);
        }
        boolean up = data.get(n - 1) >= data.get(0);
        int col = up ? 0xFF26A69A : 0xFFEF5350;
        line.setColor(col);
        Path f = new Path(p);
        f.lineTo(w - pad, h);
        f.lineTo(pad, h);
        f.close();
        fill.setShader(new LinearGradient(0, 0, 0, h, (col & 0x00FFFFFF) | 0x66000000, (col & 0x00FFFFFF), Shader.TileMode.CLAMP));
        canvas.drawPath(f, fill);
        canvas.drawPath(p, line);
    }
}
