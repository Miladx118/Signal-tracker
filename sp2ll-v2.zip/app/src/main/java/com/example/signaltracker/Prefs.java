package com.example.signaltracker;

import android.content.Context;
import android.content.SharedPreferences;

/** تنظیمات ساده برنامه (SharedPreferences). */
final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("sp2ll_prefs", Context.MODE_PRIVATE);
    }

    static String token(Context c) { return sp(c).getString("token", "").trim(); }
    static String channel(Context c) { return sp(c).getString("channel", "").trim(); }

    static double startBalance(Context c) { return getD(c, "start_balance", 1000.0); }
    static double riskPct(Context c) { return getD(c, "risk_pct", 0.5); }
    static int alarmSeconds(Context c) { return sp(c).getInt("alarm_sec", 20); }
    static boolean alarmOn(Context c) { return sp(c).getBoolean("alarm_on", true); }

    static boolean running(Context c) { return sp(c).getBoolean("running", false); }
    static void setRunning(Context c, boolean v) { sp(c).edit().putBoolean("running", v).apply(); }

    static long lastUpdateId(Context c) { return sp(c).getLong("last_update_id", 0L); }
    static void setLastUpdateId(Context c, long v) { sp(c).edit().putLong("last_update_id", v).apply(); }

    static void save(Context c, String token, String channel, double startBalance,
                     double riskPct, int alarmSec, boolean alarmOn) {
        sp(c).edit()
                .putString("token", token.trim())
                .putString("channel", channel.trim())
                .putString("start_balance", String.valueOf(startBalance))
                .putString("risk_pct", String.valueOf(riskPct))
                .putInt("alarm_sec", alarmSec)
                .putBoolean("alarm_on", alarmOn)
                .apply();
    }

    private static double getD(Context c, String key, double def) {
        try {
            return Double.parseDouble(sp(c).getString(key, String.valueOf(def)));
        } catch (Exception e) {
            return def;
        }
    }
}
