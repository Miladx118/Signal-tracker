package com.example.signaltracker;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/** سرویس پیش‌زمینه: دریافت دائمی پیام‌های تلگرام (Long Polling) حتی وقتی برنامه بسته است. */
public class SignalService extends Service {
    private static final int NOTIF_ID = 77;
    private static final AtomicInteger GEN = new AtomicInteger();

    private volatile boolean alive = false;
    private volatile HttpURLConnection conn;
    private PowerManager.WakeLock wl;
    private NotificationManager nm;
    private String lastNotifText = "";

    public static void start(Context c) {
        Intent i = new Intent(c, SignalService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    public static void stop(Context c) {
        c.stopService(new Intent(c, SignalService.class));
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notifier.ensureChannels(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, Notifier.serviceNotification(this, "در حال اتصال…"));
        if (!alive) {
            alive = true;
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sp2ll:poll");
                    wl.setReferenceCounted(false);
                    wl.acquire();
                }
            } catch (Exception ignored) {
            }
            final int gen = GEN.incrementAndGet();
            new Thread(new Runnable() {
                @Override public void run() { loop(gen); }
            }, "sp-poll").start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        alive = false;
        GEN.incrementAndGet();
        HttpURLConnection c = conn;
        if (c != null) {
            try { c.disconnect(); } catch (Exception ignored) { }
        }
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception ignored) {
        }
        SignalStore.setStatus("متوقف", false);
        super.onDestroy();
    }

    private boolean active(int gen) {
        return alive && GEN.get() == gen;
    }

    private void loop(int gen) {
        int fails = 0;
        while (active(gen)) {
            String token = Prefs.token(this);
            String channel = Prefs.channel(this);
            if (token.isEmpty() || channel.isEmpty()) {
                report("توکن یا آیدی کانال تنظیم نشده", "تنظیمات ناقص است", false);
                sleep(4000);
                continue;
            }
            HttpURLConnection c = null;
            try {
                String url = "https://api.telegram.org/bot" + token + "/getUpdates?offset="
                        + (Prefs.lastUpdateId(this) + 1) + "&timeout=25&allowed_updates="
                        + URLEncoder.encode("[\"channel_post\",\"message\"]", "UTF-8");
                c = (HttpURLConnection) new URL(url).openConnection();
                conn = c;
                c.setConnectTimeout(15000);
                c.setReadTimeout(40000);
                int code = c.getResponseCode();
                if (code != 200) {
                    String msg;
                    if (code == 409) msg = "تداخل: Webhook فعال است یا برنامه دیگری از همین ربات می‌خواند";
                    else if (code == 401 || code == 404) msg = "توکن ربات نامعتبر است";
                    else msg = "خطای تلگرام (" + code + ")";
                    report(msg, msg, false);
                    fails++;
                    sleep(Math.min(30000L, 3000L * fails));
                    continue;
                }
                String body = read(c.getInputStream());
                JSONObject json = new JSONObject(body);
                JSONArray res = json.optJSONArray("result");
                if (res != null) {
                    for (int i = 0; i < res.length(); i++) {
                        JSONObject u = res.getJSONObject(i);
                        long uid = u.getLong("update_id");
                        try {
                            handle(u, channel);
                        } catch (Exception ignored) {
                        }
                        Prefs.setLastUpdateId(this, uid);
                    }
                }
                fails = 0;
                String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
                report("متصل · آخرین بررسی " + t, "متصل و در حال دریافت سیگنال", true);
            } catch (Exception e) {
                if (!active(gen)) break;
                fails++;
                report("قطع ارتباط؛ تلاش دوباره…", "قطع ارتباط؛ تلاش دوباره…", false);
                sleep(Math.min(30000L, 3000L * fails));
            } finally {
                if (c != null) {
                    try { c.disconnect(); } catch (Exception ignored) { }
                }
            }
        }
    }

    private void handle(JSONObject u, String channel) {
        JSONObject post = u.optJSONObject("channel_post");
        if (post == null) post = u.optJSONObject("message");
        if (post == null) return;
        JSONObject chat = post.optJSONObject("chat");
        if (chat == null || !matches(chat, channel)) return;

        String text = post.optString("text", "");
        if (text.isEmpty()) text = post.optString("caption", ""); // پیام‌های دارای اسکرین‌شات
        if (text.isEmpty()) return;

        long dateMs = post.optLong("date", 0) * 1000L;
        if (dateMs <= 0) dateMs = System.currentTimeMillis();
        boolean fresh = System.currentTimeMillis() - dateMs <= 5 * 60 * 1000L; // پیام‌های قدیمی بدون آلارم

        SignalParser.Parsed p = SignalParser.parse(text);
        if (p == null) return;

        if ("SIGNAL".equals(p.kind)) {
            SignalStore.Signal s = new SignalStore.Signal();
            s.id = p.id;
            s.msgId = post.optLong("message_id", 0);
            s.buy = p.buy;
            s.symbol = p.symbol;
            s.tf = p.tf;
            s.strategy = p.strategy;
            s.time = dateMs;
            s.entry = p.entry;
            s.sl = p.sl;
            s.tp1 = p.tp1;
            s.tp2 = p.tp2;
            s.tp3 = p.tp3;
            s.risk = Prefs.riskPct(this);
            if (SignalStore.add(this, s) && fresh) {
                Notifier.signalAlarm(this, s, Prefs.alarmOn(this) ? Prefs.alarmSeconds(this) : 0);
            }
        } else if ("RESULT".equals(p.kind)) {
            SignalStore.Signal s = SignalStore.applyResult(this, p.id, p.resultKind, dateMs);
            if (s != null && fresh) Notifier.resultNotification(this, s);
        }
    }

    private static boolean matches(JSONObject chat, String channel) {
        String id = String.valueOf(chat.optLong("id"));
        String ch = channel.trim();
        if (id.equals(ch) || id.equals("-100" + ch) || id.equals(ch.replace("-100", ""))) return true;
        String un = chat.optString("username", "");
        if (un.isEmpty()) return false;
        return ("@" + un).equalsIgnoreCase(ch) || un.equalsIgnoreCase(ch);
    }

    private void report(String status, String notif, boolean ok) {
        SignalStore.setStatus(status, ok);
        if (!notif.equals(lastNotifText)) {
            lastNotifText = notif;
            try {
                if (nm != null) nm.notify(NOTIF_ID, Notifier.serviceNotification(this, notif));
            } catch (Exception ignored) {
            }
        }
    }

    private static String read(InputStream in) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        return sb.toString();
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
