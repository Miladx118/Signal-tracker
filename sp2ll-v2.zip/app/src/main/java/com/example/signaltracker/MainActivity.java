package com.example.signaltracker;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tvStatus, tvBalance, tvNet, tvWinRate, tvWins, tvLosses, tvOpen, tvEmpty;
    private View statusDot, bannerAlarm;
    private MaterialButton btnToggle;
    private EquityView equity;
    private SignalAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        tvBalance = findViewById(R.id.tvBalance);
        tvNet = findViewById(R.id.tvNet);
        tvWinRate = findViewById(R.id.tvWinRate);
        tvWins = findViewById(R.id.tvWins);
        tvLosses = findViewById(R.id.tvLosses);
        tvOpen = findViewById(R.id.tvOpen);
        tvEmpty = findViewById(R.id.tvEmpty);
        statusDot = findViewById(R.id.statusDot);
        bannerAlarm = findViewById(R.id.bannerAlarm);
        btnToggle = findViewById(R.id.btnToggle);
        equity = findViewById(R.id.equity);

        RecyclerView rv = findViewById(R.id.rvSignals);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SignalAdapter();
        rv.setAdapter(adapter);

        ImageButton btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        findViewById(R.id.btnStopAlarm).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Notifier.stopAlarm();
            }
        });

        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                toggle();
            }
        });

        Notifier.ensureChannels(this);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra("stop_alarm", false)) {
            Notifier.stopAlarm();
        }
    }

    private void toggle() {
        if (Prefs.running(this)) {
            Prefs.setRunning(this, false);
            SignalService.stop(this);
        } else {
            if (Prefs.token(this).isEmpty() || Prefs.channel(this).isEmpty()) {
                Toast.makeText(this, "ابتدا توکن ربات و آیدی کانال را در تنظیمات وارد کنید", Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, SettingsActivity.class));
                return;
            }
            Prefs.setRunning(this, true);
            SignalService.start(this);
        }
        refresh();
    }

    @Override
    protected void onStart() {
        super.onStart();
        SignalStore.setListener(new Runnable() {
            @Override public void run() { refresh(); }
        });
        refresh();
    }

    @Override
    protected void onStop() {
        SignalStore.setListener(null);
        super.onStop();
    }

    private void refresh() {
        boolean running = Prefs.running(this);
        int green = 0xFF26A69A, red = 0xFFEF5350, amber = 0xFFFFB74D, gray = 0xFF787B86;

        btnToggle.setText(running ? "توقف دریافت سیگنال" : "شروع دریافت سیگنال");
        btnToggle.setBackgroundTintList(ColorStateList.valueOf(running ? red : green));

        String st = running ? SignalStore.status() : "متوقف";
        tvStatus.setText(st);
        int dot = !running ? gray : (SignalStore.statusOk() ? green : amber);
        ViewCompat.setBackgroundTintList(statusDot, ColorStateList.valueOf(dot));

        SignalStore.Stats s = SignalStore.stats(this);
        tvBalance.setText(String.format(Locale.US, "%,.2f", s.balance));
        tvNet.setText((s.netPct >= 0 ? "+" : "") + String.format(Locale.US, "%.2f", s.netPct) + "%");
        tvNet.setTextColor(s.netPct >= 0 ? green : red);
        tvWinRate.setText(String.format(Locale.US, "%.0f%%", s.winRate));
        tvWins.setText(String.valueOf(s.wins));
        tvLosses.setText(String.valueOf(s.losses));
        tvOpen.setText(String.valueOf(s.open));
        equity.setData(s.equity);

        List<SignalStore.Signal> list = SignalStore.snapshot(this);
        adapter.submit(list);
        tvEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);

        bannerAlarm.setVisibility(Notifier.isAlarmPlaying() ? View.VISIBLE : View.GONE);
    }
}
