package com.example.telegramsignal;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText etToken, etChannelId;
    private TextView tvStatus, tvMessages;
    private Button btnStart;
    private String botToken, channelId;
    private long lastUpdateId = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private boolean isPolling = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etToken = findViewById(R.id.etToken);
        etChannelId = findViewById(R.id.etChannelId);
        btnStart = findViewById(R.id.btnStart);
        tvStatus = findViewById(R.id.tvStatus);
        tvMessages = findViewById(R.id.tvMessages);

        btnStart.setOnClickListener(v -> {
            botToken = etToken.getText().toString().trim();
            channelId = etChannelId.getText().toString().trim();
            
            if (botToken.isEmpty() || channelId.isEmpty()) {
                Toast.makeText(this, "توکن و آیدی کانال را وارد کنید", Toast.LENGTH_SHORT).show();
                return;
            }
            
            if (!isPolling) {
                isPolling = true;
                btnStart.setText("توقف دریافت");
                tvStatus.setText("وضعیت: در حال دریافت سیگنال‌ها...");
                startPolling();
            } else {
                isPolling = false;
                btnStart.setText("شروع دریافت سیگنال");
                tvStatus.setText("وضعیت: متوقف شد");
            }
        });
    }

    private void startPolling() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isPolling) return;
                fetchUpdates();
                handler.postDelayed(this, 5000); // بررسی هر ۵ ثانیه
            }
        }, 0);
    }

    private void fetchUpdates() {
        executor.execute(() -> {
            try {
                String urlStr = "https://api.telegram.org/bot" + botToken +
                        "/getUpdates?offset=" + (lastUpdateId + 1) +
                        "&timeout=1&allowed_updates=[\"channel_post\"]";
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);

                if (conn.getResponseCode() != 200) {
                    runOnUiThread(() -> tvStatus.setText("خطا: توکن نامعتبر است یا مشکل شبکه"));
                    return;
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                conn.disconnect();

                JSONObject json = new JSONObject(sb.toString());
                JSONArray result = json.optJSONArray("result");
                if (result == null || result.length() == 0) return;

                for (int i = 0; i < result.length(); i++) {
                    JSONObject update = result.getJSONObject(i);
                    lastUpdateId = update.getLong("update_id");

                    if (update.has("channel_post")) {
                        JSONObject post = update.getJSONObject("channel_post");
                        long chatId = post.getJSONObject("chat").getLong("id");
                        String chatIdStr = String.valueOf(chatId);
                        String text = post.optString("text", "[پیام بدون متن]");

                        // بررسی اینکه پیام از کانال مورد نظر است یا خیر
                        if (chatIdStr.equals(channelId) || 
                            chatIdStr.equals(channelId.replace("-100", "")) ||
                            chatIdStr.equals("-100" + channelId)) {
                            runOnUiThread(() -> {
                                String current = tvMessages.getText().toString();
                                tvMessages.setText(text + "\n\n--------------------\n\n" + current);
                            });
                        }
                    }
                }
            } catch (Exception e) {
                runOnUiThread(() -> tvStatus.setText("خطای شبکه: " + e.getMessage()));
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isPolling = false;
        executor.shutdown();
    }
}